from .typing import SMTPStatus


# alias SMTPStatus for backwards compatibility
__all__ = ("SMTPStatus",)
